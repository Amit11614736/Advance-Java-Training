package problem_statement7_2;

public class AgeIsNotWithInTheRangeException extends Exception {

}
