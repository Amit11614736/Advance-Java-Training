package problem_statement1_2;
import java.util.Scanner;
public class Rectangle 
{
    int length,breadth,area; 
   
    public Rectangle()
    {
    	length = 0;
    	breadth= 0;
    }

    void input() {
        Scanner a = new Scanner(System.in);
        System.out.print("Enter length of rectangle: ");
        length = a.nextInt();
        System.out.print("Enter breadth of rectangle: ");
        breadth = a.nextInt();
    }

    void calculate() {
        area = length * breadth;
        
    }

    void display() {
        System.out.println("Area of the Rectangle = " + area);
       
    }

    public static void main(String args[]) {
        Rectangle ob1 = new Rectangle();
        ob1.input();
        ob1.calculate();
        ob1.display();
        System.out.println("****************************");
        Rectangle ob2 = new Rectangle();
        ob2.input();
        ob2.calculate();
        ob2.display();
        System.out.println("****************************");
        Rectangle ob3 = new Rectangle();
        ob3.input();
        ob3.calculate();
        ob3.display();
        System.out.println("****************************");
        Rectangle ob4 = new Rectangle();
        ob4.input();
        ob4.calculate();
        ob4.display();
        System.out.println("****************************");
        Rectangle ob5 = new Rectangle();
        ob5.input();
        ob5.calculate();
        ob5.display();
    }
}