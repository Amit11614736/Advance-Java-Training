package problem_statement1_1;

import java.util.Scanner;
public class Even 
{

	  public static void main(String args[]) {

	  Scanner a = new Scanner(System.in);
	  System.out.println("Enter the value of n : ");
	  
	  int n = a.nextInt();

	  for (int i = 1; i <= n; i++) {

	   if (i % 2 == 0) {

	  System.out.print(i + " ");

	   }

	   }

	  }

	}